import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class DisplayData extends JFrame {

    // JDBC credentials
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/movie_booking";
    static final String JDBC_USER = "root";  // replace with your MySQL username
    static final String JDBC_PASSWORD = "yash@2002";  // replace with your MySQL password

    private JTable table;
    private DefaultTableModel tableModel;

    // Background image
    private Image backgroundImage;

    public DisplayData(int userId) {  // Accept userId as a parameter
        setTitle("User Bookings");
        setSize(700, 400);  // Increased width for price column
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Load background image
        try {
            backgroundImage = ImageIO.read(new File("D:\\document\\JDBC\\src\\bg.jpg"));  // Update with your image path
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create a table model with column names
        String[] columnNames = {"User ID", "Username", "Movie Name", "Seats", "Booking Time", "Price"};  // Added Price column
        tableModel = new DefaultTableModel(columnNames, 0);

        // Create a JTable and set the model
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Create a custom JPanel with background image
        JPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);

        // Add the custom panel to the frame
        add(backgroundPanel);

        // Load data from the database for the specific user
        loadDataFromDatabase(userId);

        setVisible(true);
    }

    // Custom JPanel to draw the background image
    private class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 100, 100, getWidth(), getHeight(), this);
            }
        }
    }

    private void loadDataFromDatabase(int userId) {  // Accept userId as a parameter
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            // Updated query to include the price
            String query = "SELECT users.id, users.username, bookings.movie_name, bookings.seats, bookings.booking_time, bookings.priceLabel " +
                    "FROM users " +
                    "LEFT JOIN bookings ON users.id = bookings.user_id " +
                    "WHERE users.id = ?";  // Filter by user ID
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, userId);  // Set the user ID parameter
                try (ResultSet rs = stmt.executeQuery()) {
                    // Loop through the result set and add rows to the table
                    while (rs.next()) {
                        int userIdValue = rs.getInt("id");
                        String username = rs.getString("username");
                        String movieName = rs.getString("movie_name");
                        int seats = rs.getInt("seats");
                        Timestamp bookingTime = rs.getTimestamp("booking_time");
                        double price = rs.getDouble("priceLabel");  // Retrieve the price

                        // Add row data to the table model
                        tableModel.addRow(new Object[]{
                                userIdValue,
                                username,
                                movieName,
                                seats,
                                bookingTime,
                                String.format("₹%.2f", price)  // Format price in Indian Rupees
                        });
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from database", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new DisplayData(1);  // Example user ID
    }
}
