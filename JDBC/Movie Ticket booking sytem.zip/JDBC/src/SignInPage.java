import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class SignInPage extends JFrame implements ActionListener {

    static final String JDBC_URL = "jdbc:mysql://localhost:3306/movie_booking";
    static final String JDBC_USER = "root";  // Replace with your MySQL username
    static final String JDBC_PASSWORD = "yash@2002";  // Replace with your MySQL password

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton signUpButton;
    private Image backgroundImage; // Variable to hold the background image

    public SignInPage() {
        // Load background image
        try {
            backgroundImage = ImageIO.read(new File("D:\\document\\JDBC\\src\\bg.jpg")); // Replace with your image path
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the size of the frame
        setSize(600, 400);  // Slightly larger window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Create main panel with custom paint method
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setLayout(null); // Set layout to null for absolute positioning

        // Create and style labels
        JLabel titleLabel = new JLabel("Create Your Account");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setBounds(50, 30, 500, 50);
        mainPanel.add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        usernameLabel.setBounds(50, 100, 150, 30);
        mainPanel.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(200, 100, 300, 40);
        usernameField.setBackground(new Color(51, 51, 51)); // Dark field
        usernameField.setForeground(Color.WHITE);
        usernameField.setCaretColor(Color.WHITE); // Cursor color
        mainPanel.add(usernameField);

        // Password label
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 24));
        passwordLabel.setBounds(50, 160, 150, 30);
        mainPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 160, 300, 40);
        passwordField.setBackground(new Color(51, 51, 51));
        passwordField.setForeground(Color.WHITE);
        passwordField.setCaretColor(Color.WHITE);
        mainPanel.add(passwordField);

        // Sign Up button
        signUpButton = new JButton("Sign Up") {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(getBackground());
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                super.paintComponent(g);
            }
        };
        signUpButton.setBounds(200, 230, 150, 50);
        signUpButton.setBackground(new Color(76, 175, 80)); // Green button
        signUpButton.setForeground(Color.WHITE);
        signUpButton.setFont(new Font("Arial", Font.BOLD, 24));
        signUpButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        signUpButton.addActionListener(this);
        signUpButton.setFocusPainted(false); // Remove focus rectangle
        signUpButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                signUpButton.setBackground(new Color(50, 150, 70)); // Darker green on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                signUpButton.setBackground(new Color(76, 175, 80)); // Reset to original color
            }
        });
        mainPanel.add(signUpButton);

        // Add main panel to the frame
        add(mainPanel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Account created successfully!");
                new LoginPage(); // Redirect to the login page
                dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating account.");
        }
    }

    public static void main(String[] args) {
        new SignInPage();
    }
}
