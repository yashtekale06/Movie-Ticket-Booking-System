import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.HashMap;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class MovieTicketBooking extends JFrame implements ActionListener {

    static final String JDBC_URL = "jdbc:mysql://localhost:3306/movie_booking";
    static final String JDBC_USER = "root";  // replace with your MySQL username
    static final String JDBC_PASSWORD = "yash@2002";  // replace with your MySQL password

    private JComboBox<String> movieComboBox;
    private JSpinner seatSpinner;
    private JButton bookButton;
    private JLabel priceLabel;  // Label to display the price
    private int userId;
    private String username;

    // Movie prices
    private HashMap<String, Double> moviePrices;

    // Background image
    private Image backgroundImage;

    public MovieTicketBooking(int userId, String username) {
        this.userId = userId;
        this.username = username;

        // Initialize movie prices
        moviePrices = new HashMap<>();
        moviePrices.put("Salar", 10.00);
        moviePrices.put("KGF", 15.00);
        moviePrices.put("RAMBO", 12.00);

        // Load background image
        try {
            backgroundImage = ImageIO.read(new File("D:\\document\\JDBC\\src\\bg.jpg"));  // Update with your image path
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set JFrame properties
        setTitle("Movie Ticket Booking");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);  // Reasonably larger window size
        setLocationRelativeTo(null);  // Center the window on the screen

        // Create main panel with a custom paint method for the background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER; // Center components

        // Title label
        JLabel titleLabel = new JLabel("Movie Ticket Booking");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Span across two columns
        mainPanel.add(titleLabel, gbc);

        // Movie selection label
        JLabel movieLabel = new JLabel("Select Movie:");
        movieLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        movieLabel.setForeground(Color.WHITE);
        gbc.gridwidth = 1; // Reset grid width
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(movieLabel, gbc);

        movieComboBox = new JComboBox<>(new String[]{"Salar", "KGF", "RAMBO"});
        movieComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Change font style
        gbc.gridx = 1;
        mainPanel.add(movieComboBox, gbc);

        // Seats label
        JLabel seatLabel = new JLabel("Number of Seats:");
        seatLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        seatLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(seatLabel, gbc);

        seatSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        seatSpinner.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Change font style
        gbc.gridx = 1;
        mainPanel.add(seatSpinner, gbc);

        // Price label
        priceLabel = new JLabel("Price: ₹0.00");  // Initialize price label with Indian Rupee symbol
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        priceLabel.setForeground(Color.YELLOW); // Yellow color for visibility
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2; // Center price label across two columns
        mainPanel.add(priceLabel, gbc);

        // Book button
        bookButton = new JButton("Book Ticket");
        bookButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        bookButton.setBackground(new Color(76, 175, 80)); // Green button
        bookButton.setForeground(Color.WHITE);
        bookButton.setBorderPainted(false);
        bookButton.setFocusPainted(false);
        bookButton.setOpaque(true); // Make the button opaque
        bookButton.addActionListener(this);
        gbc.gridy = 4;
        mainPanel.add(bookButton, gbc);

        // Add action listener for the movie selection
        movieComboBox.addActionListener(e -> updatePrice());

        // Add main panel to the frame
        add(mainPanel);
        setVisible(true);
    }

    // Method to update the price label based on selected movie
    private void updatePrice() {
        String selectedMovie = (String) movieComboBox.getSelectedItem();
        if (selectedMovie != null && moviePrices.containsKey(selectedMovie)) {
            double price = moviePrices.get(selectedMovie);
            int seats = (int) seatSpinner.getValue();
            double totalCost = price * seats;
            priceLabel.setText(String.format("Price: ₹%.2f", totalCost));  // Updated to Indian Rupee format
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedMovie = (String) movieComboBox.getSelectedItem();
        int seats = (int) seatSpinner.getValue();
        double price = moviePrices.get(selectedMovie);
        double totalCost = price * seats;  // Calculate total cost

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "INSERT INTO bookings (user_id, movie_name, seats, priceLabel) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, userId);
                stmt.setString(2, selectedMovie);
                stmt.setInt(3, seats);
                stmt.setDouble(4, totalCost);  // Store the total cost
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, username + " booked " + seats + " seats for " + selectedMovie + ". Total Cost: ₹" + totalCost);

                // Show the DisplayData window after booking
                new DisplayData(userId);  // Pass userId to DisplayData
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error booking ticket.");
        }
    }

    public static void main(String[] args) {
        new MovieTicketBooking(1, "JohnDoe");  // Example user ID and username
    }
}
