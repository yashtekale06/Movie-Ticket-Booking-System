import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class MovieTicketBookingWithBackgroundImage extends JFrame implements ActionListener {

    private JComboBox<String> movieComboBox;
    private JSpinner seatSpinner;
    private JButton bookButton;
    private JLabel priceLabel;
    private int userId;
    private String username;
    private Image backgroundImage; // Variable to hold the background image

    public MovieTicketBookingWithBackgroundImage(int userId, String username) {
        this.userId = userId;
        this.username = username;

        // Load background image
        try {
            backgroundImage = ImageIO.read(new File("D:\\document\\JDBC\\src\\bg.jpg")); // Replace with your image path
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set JFrame properties
        setTitle("Movie Ticket Booking");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Create main panel with custom paint method
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        // Title label
        JLabel titleLabel = new JLabel("Movie Ticket Booking");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);

        // Movie selection label
        JLabel movieLabel = new JLabel("Select Movie:");
        movieLabel.setFont(new Font("Arial", Font.BOLD, 16));
        movieLabel.setForeground(Color.WHITE);
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(movieLabel, gbc);

        movieComboBox = new JComboBox<>(new String[]{"Salar", "KGF", "RAMBO"});
        gbc.gridx = 1;
        mainPanel.add(movieComboBox, gbc);

        // Seats label
        JLabel seatLabel = new JLabel("Number of Seats:");
        seatLabel.setFont(new Font("Arial", Font.BOLD, 16));
        seatLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(seatLabel, gbc);

        seatSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        gbc.gridx = 1;
        mainPanel.add(seatSpinner, gbc);

        // Price label
        priceLabel = new JLabel("Price: ₹0.00");
        priceLabel.setFont(new Font("Arial", Font.BOLD, 20));
        priceLabel.setForeground(Color.YELLOW);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        mainPanel.add(priceLabel, gbc);

        // Book button
        bookButton = new JButton("Book Ticket");
        bookButton.setFont(new Font("Arial", Font.BOLD, 16));
        bookButton.setBackground(new Color(76, 175, 80));
        bookButton.setForeground(Color.WHITE);
        bookButton.addActionListener(this);
        gbc.gridy = 4;
        mainPanel.add(bookButton, gbc);

        // Add action listener for the movie selection
        movieComboBox.addActionListener(e -> updatePrice());

        // Add main panel to the frame
        add(mainPanel);
        setVisible(true);
    }

    // Method to update the price label based on selected movie
    private void updatePrice() {
        // Add your price updating logic here
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Add your booking logic here
    }

    public static void main(String[] args) {
        new MovieTicketBookingWithBackgroundImage(1, "JohnDoe");
    }
}
