import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {

    // Method to establish a connection to MySQL
    public static Connection getConnection() {
        Connection con = null;
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_db", "root", "yash@2002");

            System.out.println("Connection to the database established successfully!");

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection failed! Check the MySQL URL, username, or password.");
            e.printStackTrace();
        }

        return con;
    }

    // Method to insert a new user into the database
    public static void insertUser(String username, String password) {
        Connection con = getConnection();
        if (con != null) {
            String insertSQL = "INSERT INTO users (username, password) VALUES (?, ?)";

            try {
                // Prepare the SQL statement
                PreparedStatement pstmt = con.prepareStatement(insertSQL);
                pstmt.setString(1, username); // Set username
                pstmt.setString(2, password); // Set password

                // Execute the statement
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("New user inserted successfully!");
                }

                // Close the connection
                pstmt.close();
                con.close();
            } catch (SQLException e) {
                System.out.println("Failed to insert user into the database.");
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        // Test the user insertion (Example sign-in)
        String username = "testuser";
        String password = "testpassword";

        // Insert the new user
        insertUser(username, password);
    }
}
