import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class LoginPage extends JFrame implements ActionListener {

    static final String JDBC_URL = "jdbc:mysql://localhost:3306/movie_booking";
    static final String JDBC_USER = "root";  // replace with your MySQL username
    static final String JDBC_PASSWORD = "yash@2002";  // replace with your MySQL password

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signUpButton;
    private Image backgroundImage; // Variable to hold the background image

    public LoginPage() {
        // Load background image
        try {
            backgroundImage = ImageIO.read(new File("D:\\document\\JDBC\\src\\bg.jpg")); // Replace with your image path
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the size of the frame
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Create main panel with custom paint method
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        mainPanel.setLayout(null); // Set layout to null for absolute positioning

        // Create and style labels
        JLabel titleLabel = new JLabel("Login to Your Account");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setBounds(50, 30, 500, 50);
        mainPanel.add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        usernameLabel.setBounds(50, 100, 150, 30);
        mainPanel.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(200, 100, 300, 40);
        usernameField.setBackground(new Color(51, 51, 51)); // Dark field
        usernameField.setForeground(Color.WHITE);
        usernameField.setCaretColor(Color.WHITE); // Cursor color
        mainPanel.add(usernameField);

        // Password label
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 24));
        passwordLabel.setBounds(50, 160, 150, 30);
        mainPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 160, 300, 40);
        passwordField.setBackground(new Color(51, 51, 51));
        passwordField.setForeground(Color.WHITE);
        passwordField.setCaretColor(Color.WHITE);
        mainPanel.add(passwordField);

        // Login button
        loginButton = new JButton("Login") {
            // Override paintComponent to create rounded corners
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(getBackground());
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        loginButton.setBounds(100, 230, 150, 50);
        loginButton.setBackground(new Color(76, 175, 80)); // Green button
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 24));
        loginButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        loginButton.addActionListener(this);
        loginButton.setFocusPainted(false); // Remove focus rectangle
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(56, 139, 56)); // Darker green on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(76, 175, 80)); // Reset to original color
            }
        });
        mainPanel.add(loginButton);

        // Sign Up button
        signUpButton = new JButton("Sign Up") {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(getBackground());
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        signUpButton.setBounds(300, 230, 150, 50);
        signUpButton.setBackground(new Color(66, 133, 244)); // Blue button
        signUpButton.setForeground(Color.WHITE);
        signUpButton.setFont(new Font("Arial", Font.BOLD, 24));
        signUpButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignInPage();
                dispose();
            }
        });
        signUpButton.setFocusPainted(false); // Remove focus rectangle
        signUpButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                signUpButton.setBackground(new Color(50, 100, 200)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                signUpButton.setBackground(new Color(66, 133, 244)); // Reset to original color
            }
        });
        mainPanel.add(signUpButton);

        // Add main panel to the frame
        add(mainPanel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Validate username format
        if (!isValidUsername(username)) {
            JOptionPane.showMessageDialog(this, "Username must be alphanumeric and at least 3 characters long.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("id");
                    JOptionPane.showMessageDialog(this, "Login Successful!");
                    new MovieTicketBooking(userId, username);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Username validation method
    private boolean isValidUsername(String username) {
        return username.matches("^[a-zA-Z0-9]{3,}$"); // Alphanumeric and at least 3 characters
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}
